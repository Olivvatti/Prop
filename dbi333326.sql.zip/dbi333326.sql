-- phpMyAdmin SQL Dump
-- version 4.2.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 21, 2016 at 05:49 PM
-- Server version: 5.5.11
-- PHP Version: 5.5.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dbi333326`
--

-- --------------------------------------------------------

--
-- Table structure for table `camp`
--

CREATE TABLE IF NOT EXISTS `camp` (
  `CampID` int(11) NOT NULL,
  `Description` varchar(200) DEFAULT NULL,
  `MaxPerson` int(11) NOT NULL,
  `Available` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `camping_res`
--

CREATE TABLE IF NOT EXISTS `camping_res` (
  `CampRes_No` int(11) NOT NULL,
  `Start_Date` date NOT NULL,
  `End_Date` date NOT NULL,
  `Account_ID` int(11) NOT NULL,
  `CAMP_CampID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `e_account`
--

CREATE TABLE IF NOT EXISTS `e_account` (
  `Account_ID` int(11) NOT NULL,
  `RFID_Code` char(20) DEFAULT NULL,
  `Balance` decimal(10,3) NOT NULL,
  `E_mail` varchar(30) NOT NULL,
  `First_Name` varchar(50) NOT NULL,
  `Last_Name` varchar(50) NOT NULL,
  `Phone` char(20) DEFAULT NULL,
  `Payment_Status` tinyint(1) NOT NULL,
  `Pay_InAdvance` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `groupmembers`
--

CREATE TABLE IF NOT EXISTS `groupmembers` (
  `GroupID` int(11) NOT NULL,
  `Co_email` varchar(20) NOT NULL,
  `CampRes_No` int(11) NOT NULL,
  `Check_in` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `camp`
--
ALTER TABLE `camp`
 ADD PRIMARY KEY (`CampID`);

--
-- Indexes for table `camping_res`
--
ALTER TABLE `camping_res`
 ADD PRIMARY KEY (`CampRes_No`);

--
-- Indexes for table `e_account`
--
ALTER TABLE `e_account`
 ADD PRIMARY KEY (`Account_ID`);

--
-- Indexes for table `groupmembers`
--
ALTER TABLE `groupmembers`
 ADD PRIMARY KEY (`GroupID`,`Co_email`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
